"use strict";(function(){if(document.getElementById("ueda-widget-container"))return;const C=chrome.runtime.getURL("icon.png"),N="https://keqgzvcahsvseowfowwu.supabase.co/functions/v1/fn-sv03?check=updates",l=new Audio;l.volume=.4;const u=new Audio;u.volume=.6;function L(){try{chrome.storage.local.get(["uedaSoundMuted"],e=>{e.uedaSoundMuted||l.src&&(l.currentTime=0,l.play().catch(()=>{}))})}catch{}}function R(){try{chrome.storage.local.get(["uedaWelcomePlayedAt","uedaSoundMuted"],e=>{e.uedaSoundMuted||Date.now()-(e.uedaWelcomePlayedAt||0)<6*3600*1e3||u.src&&u.play().then(()=>{chrome.storage.local.set({uedaWelcomePlayedAt:Date.now()})}).catch(()=>{})})}catch{}}function P(){document.__uedaChatAttached||(document.__uedaChatAttached=!0,document.addEventListener("keydown",e=>{if(e.key!=="Enter"||e.shiftKey)return;const t=e.target;if(!t)return;((t.tagName||"").toLowerCase()==="textarea"||t.getAttribute&&t.getAttribute("contenteditable")==="true")&&L()},!0),document.addEventListener("click",e=>{const t=e.target&&e.target.closest&&e.target.closest("button");if(!t)return;const a=((t.getAttribute("aria-label")||"")+" "+(t.textContent||"")).toLowerCase();(a.includes("send")||a.includes("enviar")||t.type==="submit")&&L()},!0))}function k(e,t){let a=document.getElementById(e);if(!t){a&&a.remove();return}a||(a=document.createElement("style"),a.id=e,document.documentElement.appendChild(a)),a.textContent=t}function V(e){return`
      :root, body { --ueda-accent: ${e}; }
      @keyframes ueda-chat-glow {
        0%, 100% { box-shadow: 0 0 0 2px ${e}, 0 0 20px color-mix(in srgb, ${e} 35%, transparent) !important; }
        50%      { box-shadow: 0 0 0 2px ${e}, 0 0 32px color-mix(in srgb, ${e} 60%, transparent) !important; }
      }
      body.ueda-monitor-on textarea[placeholder*="Lovable" i]:not(#ueda-widget-container textarea),
      body.ueda-monitor-on textarea[placeholder*="Pergunte" i]:not(#ueda-widget-container textarea),
      body.ueda-monitor-on textarea[placeholder*="Ask" i]:not(#ueda-widget-container textarea) {
        outline: 2px solid ${e} !important;
        outline-offset: 2px !important;
        border-radius: 12px !important;
        animation: ueda-chat-glow 2.4s ease-in-out infinite !important;
        transition: outline-color .25s ease !important;
      }
      body.ueda-monitor-on form.relative,
      body.ueda-monitor-on .relative form,
      body.ueda-monitor-on [class*="ChatInput"],
      body.ueda-monitor-on [class*="chat-input"],
      body.ueda-monitor-on [data-testid="chat-input"],
      body.ueda-monitor-on [data-testid="chat-input-container"] {
        border-radius: 14px !important;
        animation: ueda-chat-glow 2.4s ease-in-out infinite !important;
      }
      @media (prefers-reduced-motion: reduce) {
        body.ueda-monitor-on [class*="chat"], body.ueda-monitor-on textarea { animation: none !important; }
      }
    `}function m(e){try{document.querySelectorAll("textarea").forEach(t=>{if(t.closest("#ueda-widget-container"))return;const a=(t.placeholder||"").toLowerCase();if(!a||!/lovable|pergunte|ask/.test(a))return;let n=t.parentElement;for(let o=0;o<3&&n&&n!==document.body;o+=1)n.style.setProperty("box-shadow",`0 0 0 2px ${e}, 0 0 20px ${e}55`,"important"),n.style.setProperty("border-radius","14px","important"),n.style.setProperty("transition","box-shadow .25s ease","important"),n.dataset.uedaGlow="true",n=n.parentElement})}catch{}}let p="#1E88E5";function M(){if(!document.__uedaChatHighlighterStarted){document.__uedaChatHighlighterStarted=!0,m(p),setInterval(()=>m(p),1500);try{new MutationObserver(()=>m(p)).observe(document.body,{childList:!0,subtree:!0})}catch{}}}function S(e){if(!e)return;const t=e.config&&e.config.sounds||e.sounds||{};t.chat&&(l.src=t.chat),t.welcome&&(u.src=t.welcome,u.addEventListener("canplaythrough",R,{once:!0}));const a=e.settings||{},n=a.brand_color||a.widget_accent_color||e.accent||"#1E88E5";document.documentElement.style.setProperty("--ueda-accent",n),document.body.style.setProperty("--ueda-accent",n),d&&d.style.setProperty("--ueda-accent",n),p=n,k("ueda-runtime-chat-css",V(n)),k("ueda-remote-custom-css",a.chat_custom_css||a.custom_css||e.custom_css||"");const o=document.getElementById("ueda-menu-help"),s=a.support_url||(a.whatsapp?`https://wa.me/${a.whatsapp}`:"");o&&s&&(o.href=s),F(Array.isArray(e.skills)?e.skills:[]),P(),M(),m(n)}function g(e,t="success",a=3200){try{const n=document.createElement("div");n.className="ueda-toast ueda-toast-"+t,n.innerHTML=`
        <span class="ueda-toast-icon">${t==="success"?"\u2713":t==="error"?"!":"i"}</span>
        <span class="ueda-toast-msg"></span>
      `,n.querySelector(".ueda-toast-msg").textContent=e,document.body.appendChild(n),requestAnimationFrame(()=>n.classList.add("ueda-toast-in")),setTimeout(()=>{n.classList.remove("ueda-toast-in"),setTimeout(()=>n.remove(),320)},a)}catch{}}window.uedaToast=g;function q(e,t){const a=String(e||"0").split(".").map(o=>parseInt(o,10)||0),n=String(t||"0").split(".").map(o=>parseInt(o,10)||0);for(let o=0;o<Math.max(a.length,n.length);o++){const s=(a[o]||0)-(n[o]||0);if(s!==0)return s}return 0}function y(e){if(!(!e||typeof e!="string")&&document.__uedaCoreInjected!==e){document.__uedaCoreInjected=e;try{const t=document.createElement("script");t.type="text/javascript",t.textContent=e,(document.head||document.documentElement).appendChild(t),t.remove()}catch{}}}function j(e){const t=document.getElementById("ueda-menu-update");if(t&&(t.classList.add("ueda-has-update"),!t.querySelector(".ueda-update-dot"))){const a=document.createElement("span");a.className="ueda-update-dot",a.title=`Nova vers\xE3o ${e} dispon\xEDvel`,t.appendChild(a)}}async function v({announce:e=!1}={}){const t=chrome.runtime.getManifest().version||"0.0.0",a=await fetch(N,{cache:"no-store",headers:{"x-ext-version":t}});if(!a.ok)throw new Error(`Falha ao sincronizar (${a.status})`);const n=await a.json();S(n),n&&typeof n.core_js=="string"&&y(n.core_js),chrome.storage.local.set({uedaRemoteConfig:n,uedaLastSyncAt:Date.now()});const o=n&&(n.version||n.release&&n.release.version);return o&&q(o,t)>0?(j(o),e&&g(`Nova vers\xE3o ${o} dispon\xEDvel`,"info",4200)):e&&g("Extens\xE3o sincronizada com o servidor","success"),e&&m(p),n}const D=`
    <div id="ueda-widget-container" class="ueda-collapsed">
      <div class="ueda-widget-menu">
        <div class="ueda-menu-header" id="ueda-menu-toggle">
          <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"></polyline></svg>
          <span class="ueda-text" id="ueda-toggle-text">Expandir menu</span>
        </div>

        <div class="ueda-menu-item" style="cursor: default;">
          <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
          <div class="ueda-text" style="display: flex; flex-direction: column;">
            <span id="ueda-user-name">Minha conta</span>
            <span id="ueda-time-value" style="font-size: 11px; color: #1E88E5; font-weight: bold; margin-top: 2px;">Calculando...</span>
            <span id="ueda-version-value" style="font-size: 10px; color: #6b7280; font-weight: 500; margin-top: 2px; letter-spacing: 0.05em;">v1.0</span>
          </div>
        </div>

        <div class="ueda-menu-item" id="ueda-menu-mode">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="4"></circle></svg> 
          <span class="ueda-text" id="ueda-mode-text">Modo Padr\xE3o</span>
        </div>

        <div id="ueda-remote-skills"></div>

        <div class="ueda-menu-item" id="ueda-menu-watermark">
          <svg viewBox="0 0 24 24"><path d="m7 21-4-4 12-12a3 3 0 0 1 4 4L7 21Z"></path><path d="M14 7 17 10"></path><path d="M5 19h16"></path></svg>
          <span class="ueda-text">Remover marca d'\xE1gua</span>
        </div>

        <div class="ueda-menu-item" id="ueda-menu-update">
          <svg viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>
          <span class="ueda-text">Atualizar extens\xE3o</span>
        </div>

        <a href="https://wa.me/5511999999999" target="_blank" class="ueda-menu-item" id="ueda-menu-help" style="text-decoration: none;">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line></svg> 
          <span class="ueda-text">Ajuda & Suporte</span>
        </a>


        <div class="ueda-menu-item ueda-text-red" id="ueda-menu-status">
          <svg viewBox="0 0 24 24"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"></path><line x1="12" y1="2" x2="12" y2="12"></line></svg> 
          <span class="ueda-text" id="ueda-status-text">Logoff</span>
        </div>

      </div>
      <button class="ueda-widget-btn" id="ueda-fab" aria-label="Abrir op\xE7\xF5es UEDA EX" title="Abrir op\xE7\xF5es UEDA EX">
        <img src="${C}" alt="U" class="ueda-widget-logo">
      </button>
    </div>
  `;document.body.insertAdjacentHTML("beforeend",D);const d=document.getElementById("ueda-widget-container");d&&(d.style.display="none");const B=document.getElementById("ueda-fab"),H=document.getElementById("ueda-menu-toggle"),c=document.getElementById("ueda-toggle-text"),i=document.getElementById("ueda-time-value"),U=document.getElementById("ueda-menu-mode"),z=document.getElementById("ueda-mode-text"),x=document.getElementById("ueda-menu-status"),W=document.getElementById("ueda-status-text");function K(e){return!!(e&&e.licenseKey&&e.authStatus==="success"&&e.keyValid===!0)}function h(e){return K(e)?(d&&(d.style.display=""),!0):(document.body.classList.remove("ueda-monitor-on"),d&&(d.style.display="none"),!1)}const b=document.getElementById("ueda-menu-update");b&&b.addEventListener("click",async()=>{const e=b.querySelector(".ueda-text"),t=e?e.textContent:"";e&&(e.textContent="Atualizando...");let a=!1;try{await v({announce:!0}),a=!0,e&&(e.textContent="Atualizado")}catch(n){await E(n&&n.message?n.message:"N\xE3o foi poss\xEDvel sincronizar a extens\xE3o agora.",{okText:"OK",cancelText:""})}finally{e&&setTimeout(()=>{e.textContent=t||"Atualizar extens\xE3o"},a?1200:0)}});const I=document.getElementById("ueda-menu-watermark");I&&I.addEventListener("click",()=>{try{chrome.storage.local.get(["uedaRemoteConfig"],e=>{const t=e&&e.uedaRemoteConfig&&e.uedaRemoteConfig.commands&&e.uedaRemoteConfig.commands.remove_watermark;t?y(t):document.querySelectorAll('a[href*="lovable.dev"], [class*="badge"], [class*="watermark"]').forEach(a=>{const n=(a.textContent||"").toLowerCase();(n.includes("lovable")||n.includes("made with"))&&(a.style.display="none")}),g("Marca d'\xE1gua removida!","success")})}catch{g("Falha ao remover marca d'\xE1gua","error")}});let f="1",A=!0;function O(e){const t=String(e||"").toLowerCase();return t.includes("download")?'<svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>':t.includes("eraser")||t.includes("marca")?'<svg viewBox="0 0 24 24"><path d="m7 21-4-4 12-12a3 3 0 0 1 4 4L7 21Z"></path><path d="M14 7 17 10"></path><path d="M5 19h16"></path></svg>':t.includes("note")||t.includes("sticky")?'<svg viewBox="0 0 24 24"><path d="M15.5 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5Z"></path><path d="M15 3v6h6"></path></svg>':'<svg viewBox="0 0 24 24"><path d="M9.9 10.8 8 15l-1.9-4.2L2 9l4.1-1.8L8 3l1.9 4.2L14 9l-4.1 1.8Z"></path><path d="M19 13l-1.2 2.8L15 17l2.8 1.2L19 21l1.2-2.8L23 17l-2.8-1.2L19 13Z"></path></svg>'}function w(e){return String(e||"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}function F(e){const t=document.getElementById("ueda-remote-skills");t&&(t.innerHTML=e.filter(a=>String(a.name||"").toLowerCase()!=="logoff").map(a=>`
      <div class="ueda-menu-item ueda-skill-item" title="${w(a.description||a.name)}" data-skill-id="${w(a.id)}">
        ${O(a.icon||a.name)}
        <span class="ueda-text">${w(a.name)}</span>
      </div>
    `).join(""))}function _(){d.classList.add("ueda-visible"),d.classList.add("ueda-collapsed"),d.classList.remove("ueda-expanded"),c&&(c.textContent="Expandir menu")}function X(){d.classList.remove("ueda-visible"),d.classList.remove("ueda-expanded"),d.classList.add("ueda-collapsed"),c&&(c.textContent="Expandir menu")}function Z(){d.classList.add("ueda-visible"),d.classList.add("ueda-expanded"),d.classList.remove("ueda-collapsed"),c&&(c.textContent="Recolher menu")}B&&B.addEventListener("click",()=>{d.classList.contains("ueda-visible")?X():_()}),H.addEventListener("click",()=>{d.classList.contains("ueda-expanded")?_():Z()}),chrome.storage.local.get(["enabled","mode","userName","user","licenseKey","authStatus","keyValid"],e=>{if(!h(e))return;A=e.enabled!==!1,f=e.mode||"1";const t=e.userName||e.user||"Minha conta";document.getElementById("ueda-user-name").textContent=t;try{const a=chrome.runtime.getManifest().version||"1.0",n=document.getElementById("ueda-version-value");n&&(n.textContent="v"+a)}catch{}T()}),chrome.storage.local.get(["uedaRemoteConfig","licenseKey","authStatus","keyValid"],e=>{h(e)&&(e&&e.uedaRemoteConfig&&(S(e.uedaRemoteConfig),typeof e.uedaRemoteConfig.core_js=="string"&&y(e.uedaRemoteConfig.core_js)),v().catch(()=>{}))}),setInterval(()=>{chrome.storage.local.get(["licenseKey","authStatus","keyValid"],e=>{h(e)&&v().catch(()=>{})})},300*1e3);function T(){z.textContent=f==="2"?"Modo Avan\xE7ado":"Modo Padr\xE3o",W.textContent="Logoff",x.classList.add("ueda-text-red"),x.classList.remove("ueda-text-green"),document.body.classList.toggle("ueda-monitor-on",A),M()}U.addEventListener("click",()=>{f=f==="1"?"2":"1",chrome.storage.local.set({mode:f},T)});function E(e,{okText:t="Confirmar",cancelText:a="Cancelar"}={}){return new Promise(n=>{const o=document.createElement("div");o.className="ueda-modal-overlay",o.innerHTML=`
        <div class="ueda-modal" role="dialog" aria-modal="true">
          <img src="${C}" alt="" class="ueda-modal-logo" />
          <div class="ueda-modal-title">UEDA EX</div>
          <div class="ueda-modal-msg"></div>
          <div class="ueda-modal-actions">
            <button type="button" class="ueda-modal-btn ueda-modal-cancel"></button>
            <button type="button" class="ueda-modal-btn ueda-modal-ok"></button>
          </div>
        </div>`,o.querySelector(".ueda-modal-msg").textContent=e,o.querySelector(".ueda-modal-ok").textContent=t,o.querySelector(".ueda-modal-cancel").textContent=a;const s=r=>{o.remove(),n(r)};o.querySelector(".ueda-modal-ok").addEventListener("click",()=>s(!0)),o.querySelector(".ueda-modal-cancel").addEventListener("click",()=>s(!1)),o.addEventListener("click",r=>{r.target===o&&s(!1)}),document.body.appendChild(o)})}window.uedaAlert=e=>E(e,{okText:"OK",cancelText:""}),x.addEventListener("click",async()=>{if(await E("Encerrar sess\xE3o da extens\xE3o UEDA EX?"))try{chrome.storage.local.clear(()=>{document.body.classList.remove("ueda-monitor-on");const t=document.getElementById("ueda-widget-container");t&&t.remove();try{chrome.runtime.sendMessage({action:"logoff"})}catch{}})}catch{document.getElementById("ueda-widget-container")?.remove()}});const $=setInterval(()=>{try{const e=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null,!1);let t;for(;t=e.nextNode();)if(t.nodeValue&&t.nodeValue.includes("Acesso Negado")){let a=t.parentElement;for(;a&&a!==document.body;){if(a.style.position==="absolute"||a.style.zIndex||a.style.display==="flex"){t.nodeValue="",a.querySelectorAll("svg").forEach(r=>r.style.display="none"),a.style.backgroundColor="rgba(20, 20, 20, 0.6)",a.style.backdropFilter="grayscale(1) blur(4px)";const o=document.createTreeWalker(a,NodeFilter.SHOW_TEXT,null,!1);let s;for(;s=o.nextNode();)s.nodeValue.includes("\u26A0\uFE0F")&&(s.nodeValue=s.nodeValue.replace("\u26A0\uFE0F",""));break}a=a.parentElement}}}catch{}try{if(!chrome.runtime.id){clearInterval($);return}chrome.storage.local.get(null,e=>{if(chrome.runtime.lastError||!h(e))return;let t=e.userName||e.user||e.username||e.cliente||e.clientName||e.nome||e.name||e.owner||e.usuario||"Minha conta";if(t==="Minha conta"){for(let s in e)if(typeof e[s]=="string"&&e[s].toLowerCase()==="magda"&&(t=e[s]),typeof e[s]=="string"&&(s.toLowerCase().includes("user")||s.toLowerCase().includes("name")||s.toLowerCase().includes("cliente"))&&e[s]&&e[s].length<30){t=e[s];break}}if(document.getElementById("ueda-user-name").textContent=t,!e.enabled){document.body.classList.remove("ueda-monitor-on"),i.textContent="Pausado",i.style.color="#ff8b8b";return}if(document.body.classList.add("ueda-monitor-on"),!e.validade||e.validade==="Sem validade"){i.textContent="Ilimitado",i.style.color="#70f0c1";return}let a=e.validade;if(typeof a=="string"){const s=new Date(a).getTime();if(!isNaN(s))a=s;else{i.textContent=a,i.style.color="#1E88E5";return}}const n=new Date().getTime(),o=Math.max(0,Math.floor((a-n)/1e3));if(o<=0)i.textContent="Expirado",i.style.color="#ff8b8b";else{const s=Math.floor(o/86400),r=String(Math.floor(o%(3600*24)/3600)).padStart(2,"0"),G=String(Math.floor(o%3600/60)).padStart(2,"0");if(s>0)i.textContent=`${s} dias restantes`;else{const J=String(o%60).padStart(2,"0");i.textContent=`${r}:${G}:${J}`}i.style.color="#1E88E5"}})}catch(e){e.message&&e.message.includes("Extension context invalidated")&&clearInterval($)}},1e3)})();
